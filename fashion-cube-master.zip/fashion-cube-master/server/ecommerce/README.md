# Full stack ecommerce online store application




#### populate data: run  `node ./seed` (make sure you fill up `mongo-config` file with mongodb url)



